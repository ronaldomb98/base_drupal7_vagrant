<?php

/**
 * @file
 * Generic transliteration data for the PhpTransliteration class.
 */

$base = [
  0x00 => 'xia', 'yuan', 'zong', 'xu', 'ying', 'wei', 'geng', 'xuan', 'ying', 'jin', 'yi', 'zhui', 'ni', 'bang', 'gu', 'pan',
  0x10 => 'zhou', 'jian', 'ci', 'quan', 'shuang', 'yun', 'xia', 'cui', 'xi', 'rong', 'tao', 'fu', 'yun', 'chen', 'gao', 'ru',
  0x20 => 'hu', 'zai', 'teng', 'xian', 'su', 'zhen', 'zong', 'tao', 'huang', 'cai', 'bi', 'feng', 'cu', 'li', 'suo', 'yan',
  0x30 => 'xi', 'zong', 'lei', 'juan', 'qian', 'man', 'zhi', 'lu', 'mu', 'piao', 'lian', 'mi', 'xuan', 'zong', 'ji', 'shan',
  0x40 => 'sui', 'fan', 'lu', 'beng', 'yi', 'sao', 'mou', 'yao', 'qiang', 'hun', 'xian', 'ji', 'sha', 'xiu', 'ran', 'xuan',
  0x50 => 'sui', 'qiao', 'zeng', 'zuo', 'zhi', 'shan', 'san', 'lin', 'yu', 'fan', 'liao', 'chuo', 'zun', 'jian', 'rao', 'chan',
  0x60 => 'rui', 'xiu', 'hui', 'hua', 'zuan', 'xi', 'qiang', 'yun', 'da', 'sheng', 'hui', 'xi', 'se', 'jian', 'jiang', 'huan',
  0x70 => 'zao', 'cong', 'xie', 'jiao', 'bi', 'dan', 'yi', 'nong', 'sui', 'yi', 'shai', 'xu', 'ji', 'bin', 'qian', 'lan',
  0x80 => 'pu', 'xun', 'zuan', 'qi', 'peng', 'yao', 'mo', 'lei', 'xie', 'zuan', 'kuang', 'you', 'xu', 'lei', 'xian', 'chan',
  0x90 => 'jiao', 'lu', 'chan', 'ying', 'cai', 'rang', 'xian', 'zui', 'zuan', 'luo', 'li', 'dao', 'lan', 'lei', 'lian', 'si',
  0xA0 => 'jiu', 'yu', 'hong', 'zhou', 'xian', 'ge', 'yue', 'ji', 'wan', 'kuang', 'ji', 'ren', 'wei', 'yun', 'hong', 'chun',
  0xB0 => 'pi', 'sha', 'gang', 'na', 'ren', 'zong', 'lun', 'fen', 'zhi', 'wen', 'fang', 'zhu', 'zhen', 'niu', 'shu', 'xian',
  0xC0 => 'gan', 'xie', 'fu', 'lian', 'zu', 'shen', 'xi', 'zhi', 'zhong', 'zhou', 'ban', 'fu', 'chu', 'shao', 'yi', 'jing',
  0xD0 => 'dai', 'bang', 'rong', 'jie', 'ku', 'rao', 'die', 'hang', 'hui', 'gei', 'xuan', 'jiang', 'luo', 'jue', 'jiao', 'tong',
  0xE0 => 'geng', 'xiao', 'juan', 'xiu', 'xi', 'sui', 'tao', 'ji', 'ti', 'ji', 'xu', 'ling', 'ying', 'xu', 'qi', 'fei',
  0xF0 => 'chuo', 'shang', 'gun', 'sheng', 'wei', 'mian', 'shou', 'beng', 'chou', 'tao', 'liu', 'quan', 'zong', 'zhan', 'wan', 'lu',
];
