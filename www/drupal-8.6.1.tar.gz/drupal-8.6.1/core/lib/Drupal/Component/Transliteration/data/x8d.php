<?php

/**
 * @file
 * Generic transliteration data for the PhpTransliteration class.
 */

$base = [
  0x00 => 'yi', 'bai', 'chen', 'wan', 'zhi', 'zhui', 'biao', 'yun', 'zeng', 'dan', 'zan', 'yan', 'pu', 'shan', 'wan', 'ying',
  0x10 => 'jin', 'gan', 'xian', 'zang', 'bi', 'du', 'shu', 'yan', 'shang', 'xuan', 'long', 'gan', 'zang', 'bei', 'zhen', 'fu',
  0x20 => 'yuan', 'gong', 'cai', 'ze', 'xian', 'bai', 'zhang', 'huo', 'zhi', 'fan', 'tan', 'pin', 'bian', 'gou', 'zhu', 'guan',
  0x30 => 'er', 'jian', 'ben', 'shi', 'tie', 'gui', 'kuang', 'dai', 'mao', 'fei', 'he', 'yi', 'zei', 'zhi', 'jia', 'hui',
  0x40 => 'zi', 'lin', 'lu', 'zang', 'zi', 'gai', 'jin', 'qiu', 'zhen', 'lai', 'she', 'fu', 'du', 'ji', 'shu', 'shang',
  0x50 => 'ci', 'bi', 'zhou', 'geng', 'pei', 'dan', 'lai', 'feng', 'zhui', 'fu', 'zhuan', 'sai', 'ze', 'yan', 'zan', 'yun',
  0x60 => 'zeng', 'shan', 'ying', 'gan', 'chi', 'xi', 'she', 'nan', 'tong', 'xi', 'cheng', 'he', 'cheng', 'zhe', 'xia', 'tang',
  0x70 => 'zou', 'zou', 'li', 'jiu', 'fu', 'zhao', 'gan', 'qi', 'shan', 'qiong', 'yin', 'xian', 'ci', 'jue', 'qin', 'chi',
  0x80 => 'ci', 'chen', 'chen', 'die', 'ju', 'chao', 'di', 'xi', 'zhan', 'jue', 'yue', 'qu', 'ji', 'chi', 'chu', 'gua',
  0x90 => 'xue', 'zi', 'tiao', 'duo', 'lie', 'gan', 'suo', 'cu', 'xi', 'zhao', 'su', 'yin', 'ju', 'jian', 'que', 'tang',
  0xA0 => 'chuo', 'cui', 'lu', 'qu', 'dang', 'qiu', 'zi', 'ti', 'qu', 'chi', 'huang', 'qiao', 'qiao', 'jiao', 'zao', 'ti',
  0xB0 => 'er', 'zan', 'zan', 'zu', 'pa', 'bao', 'ku', 'ke', 'dun', 'jue', 'fu', 'chen', 'jian', 'fang', 'zhi', 'ta',
  0xC0 => 'yue', 'ba', 'qi', 'yue', 'qiang', 'tuo', 'tai', 'yi', 'nian', 'ling', 'mei', 'ba', 'die', 'ku', 'tuo', 'jia',
  0xD0 => 'ci', 'pao', 'qia', 'zhu', 'ju', 'dian', 'zhi', 'fu', 'pan', 'ju', 'shan', 'bo', 'ni', 'ju', 'li', 'gen',
  0xE0 => 'yi', 'ji', 'duo', 'xian', 'jiao', 'duo', 'zhu', 'quan', 'kua', 'zhuai', 'gui', 'qiong', 'kui', 'xiang', 'chi', 'lu',
  0xF0 => 'pian', 'zhi', 'jia', 'tiao', 'cai', 'jian', 'ta', 'qiao', 'bi', 'xian', 'duo', 'ji', 'ju', 'ji', 'shu', 'tu',
];
